# Telegram Group Cleaner Bot

🧹 Automatically removes users from your Telegram group after 3 months.

## Setup (Railway)
1. Deploy this repo to Railway
2. Set these environment variables:
   - `BOT_TOKEN` — your bot token from BotFather
   - `GROUP_ID` — your group's chat ID (with -100 prefix)
3. Done! The bot will run 24/7.

## Features
- Tracks new members joining the group
- Saves join date in SQLite
- Deletes members after 90 days
