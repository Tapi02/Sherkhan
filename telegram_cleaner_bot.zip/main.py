from telegram import Update, ChatMember
from telegram.ext import Application, ChatMemberHandler, ContextTypes
from datetime import datetime, timedelta
import os
import sqlite3
import asyncio

TOKEN = os.getenv("BOT_TOKEN")
GROUP_ID = int(os.getenv("GROUP_ID"))

conn = sqlite3.connect("members.db", check_same_thread=False)
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS members (
    user_id INTEGER PRIMARY KEY,
    join_date TEXT
)''')
conn.commit()

async def track_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    status = update.chat_member
    if status.new_chat_member.status in [ChatMember.MEMBER, ChatMember.RESTRICTED]:
        user_id = status.new_chat_member.user.id
        cursor.execute("INSERT OR REPLACE INTO members (user_id, join_date) VALUES (?, ?)",
                       (user_id, datetime.utcnow().isoformat()))
        conn.commit()
        print(f"[INFO] Added user: {user_id}")

async def cleanup_old_members(app: Application):
    while True:
        await asyncio.sleep(86400)
        cutoff = datetime.utcnow() - timedelta(days=90)
        cursor.execute("SELECT user_id, join_date FROM members")
        for user_id, join_date in cursor.fetchall():
            try:
                join_time = datetime.fromisoformat(join_date)
                if join_time < cutoff:
                    await app.bot.ban_chat_member(GROUP_ID, user_id)
                    await app.bot.unban_chat_member(GROUP_ID, user_id)
                    cursor.execute("DELETE FROM members WHERE user_id = ?", (user_id,))
                    conn.commit()
                    print(f"[INFO] Removed user: {user_id}")
            except Exception as e:
                print(f"[ERROR] Failed to remove {user_id}: {e}")

async def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(ChatMemberHandler(track_member, ChatMemberHandler.CHAT_MEMBER))
    app.job_queue.run_once(lambda *_: asyncio.create_task(cleanup_old_members(app)), 1)
    await app.run_polling()

if __name__ == '__main__':
    asyncio.run(main())
